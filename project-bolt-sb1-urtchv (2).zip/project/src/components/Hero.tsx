import { motion } from 'framer-motion';
import { Mail, MapPin, Phone, Linkedin } from 'lucide-react';

export default function Hero() {
  return (
    <section className="min-h-screen pt-24 pb-12 bg-gradient-to-br from-gray-50 to-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <motion.img
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.2 }}
            src="https://images.unsplash.com/photo-1633332755192-727a05c4013d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MXx8aGVhZHNob3R8ZW58MHx8MHx8fDA%3D&w=200&h=200"
            alt="Profile"
            className="w-32 h-32 rounded-full mx-auto mb-8 object-cover border-4 border-white shadow-lg"
          />
          <h1 className="text-5xl font-bold text-gray-900 mb-4">Adem Bouteraa</h1>
          <p className="text-xl text-gray-600 mb-8">Business Intelligence Professional</p>
          <div className="flex flex-col md:flex-row items-center justify-center gap-4 mb-8">
            <a href="mailto:Adem.bouteraa@esen.tn" className="flex items-center gap-2 text-gray-600">
              <Mail className="w-5 h-5" />
              <span>Adem.bouteraa@esen.tn</span>
            </a>
            <a href="tel:+21652406466" className="flex items-center gap-2 text-gray-600">
              <Phone className="w-5 h-5" />
              <span>+216 52406466</span>
            </a>
            <div className="flex items-center gap-2 text-gray-600">
              <MapPin className="w-5 h-5" />
              <span>Bardo, Tunis</span>
            </div>
            <a href="https://www.linkedin.com/in/bouteraa-adem-9448781bb" className="flex items-center gap-2 text-gray-600">
              <Linkedin className="w-5 h-5" />
              <span>LinkedIn Profile</span>
            </a>
          </div>
          <p className="max-w-2xl mx-auto text-gray-600">
            Experienced business intelligence professional with expertise in data systems management and analytics. Proven track record in developing scalable solutions and driving data-driven decision making.
          </p>
        </motion.div>
      </div>
    </section>
  );
}