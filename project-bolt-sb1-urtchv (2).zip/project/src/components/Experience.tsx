import { motion } from 'framer-motion';
import { Briefcase } from 'lucide-react';

const experiences = [
  {
    company: "Institut El Amouri",
    position: "Field Supervisor / Banking Control",
    period: "2021 - 2022",
    description: "Led independent supervision of banking operations to ensure compliance and efficiency. Managed a team conducting street surveys for precise data collection and timely reporting."
  },
  {
    company: "Independent Higher Authority for Elections",
    position: "Administrative Team Leader & Data Analyst",
    period: "2023",
    description: "Directed a 3-person team in administrative strategy and task management. Cleaned and analyzed large datasets with Excel; developed Power BI dashboards to streamline operations."
  }
];

export default function Experience() {
  return (
    <section className="py-16 bg-white" id="experience">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
        >
          <div className="flex items-center gap-2 mb-8">
            <Briefcase className="w-6 h-6 text-gray-900" />
            <h2 className="text-3xl font-bold text-gray-900">Experience</h2>
          </div>
          <div className="space-y-8">
            {experiences.map((exp, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="bg-gray-50 p-6 rounded-lg shadow-sm hover:shadow-md transition-shadow"
              >
                <h3 className="text-xl font-semibold text-gray-900">{exp.position}</h3>
                <p className="text-gray-600 mt-1">{exp.company}</p>
                <p className="text-sm text-gray-500 mt-1">{exp.period}</p>
                <p className="text-gray-700 mt-4">{exp.description}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}